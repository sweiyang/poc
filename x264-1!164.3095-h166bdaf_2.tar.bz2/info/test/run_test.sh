

set -ex



test -f ${PREFIX}/include/x264.h
test ! -f ${PREFIX}/lib/libx264.a
test -f ${PREFIX}/lib/libx264${SHLIB_EXT}
test -f ${PREFIX}/lib/libx264.so.164
x264 --help
exit 0
